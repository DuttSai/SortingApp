import { Component } from '@angular/core';
import { Emp } from './emp';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 empArr:Emp[]=[
  {id:1001,empName:"Sai",empSal:20000,empDep:"javascript"},
  {id:1002,empName:"Ranjit",empSal:454545,empDep:"asjkfba"},
  {id:1003,empName:"Nava",empSal:78789,empDep:"bjyt"},
  {id:1004,empName:"Sagar",empSal:15151,empDep:"rtryyht"},
  {id:1005,empName:"Rahul",empSal:41516,empDep:"cdfdgdh"},
  {id:1006,empName:"Srikar",empSal:798552,empDep:"edgjnfj"}
]
tempArr:any[]=[]
 i:number=0;
idClick(){
  console.log("id clicked")
}
nameClick(){
  console.log("name clicked")
  this.empArr.map(x=>
    {
      this.tempArr.push(x.empName)
    })
    this.i=0
    this.tempArr.sort()
    console.log(this.tempArr)
    for(let t=0;t<=this.empArr.length;t++)
    { 
      for(let a of this.empArr){
      if(a.empName==this.tempArr[this.i]){
        console.log(a);
        this.empArr[t]=a  
      }
      
    }
    this.i++
  }
}
salClick(){
  console.log("id clicked")
}
depClick(){
  console.log("id clicked")
}

}
